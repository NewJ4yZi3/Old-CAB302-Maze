import Program.Database;
import Program.GUI;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
        javax.swing.SwingUtilities.invokeLater(() -> {
            GUI gui = new GUI();
            gui.runGUI();
        });
    }
}