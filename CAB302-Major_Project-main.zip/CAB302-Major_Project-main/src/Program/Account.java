package Program;

import java.io.IOException;
import java.io.Serial;
import java.io.Serializable;
import java.sql.SQLException;

/**
 * Represents an account with a username, password and unique accountId
 */
public class Account implements Serializable {
    @Serial
    private static final long serialVersionUID = 2315474632706440355L;
    private String username;
    private String password;
    private String accountType;
    private int accountId;
    /**
     * Constructs an account
     * @param username The name of the account
     * @param password The password of the account
     * @param accountType The type of the account
     */
    public Account(String username, String password, String accountType) throws SQLException {

        if(DatabaseHelper.db.addNewUser(username, password, accountType)) {
            this.accountId = DatabaseHelper.db.getId(username);
            this.username = username;
            this.password = password;
            this.accountType = accountType;
        }
    }

    /**
     * Adds the account object to the database
     * @throws SQLException
     * @throws IOException
     */
    public void addAccountObj() throws SQLException, IOException {
        DatabaseHelper.db.addAccountObj(this, this.accountId);
    }

    /**
     * Gets the account username
     * @return the username
     */
    public String getUsername(){
        return this.username;
    }

    /**
     * Gets the account password
     * @return the password
     */
    public String getPassword(){
        // should this simply return the password as a string
        // or should safety measures be put in place so that it returns a hash value or something
        return this.password;
    }

    /**
     * Sets the account username
     * @param newUsername The account's new username
     */
    public void setUsername(String newUsername) throws SQLException {
        if (DatabaseHelper.db.changeUsername(this.accountId, newUsername)){
            // change this if else statement to show a message in the gui
            System.out.println("The username has been successfully changed");
            this.username = newUsername;
        } else {
            System.out.println("The username was not successfully changed");
        }

    }

    /**
     * Sets the account password
     * @param newPassword The account's new password
     */
    public void setPassword(String newPassword) throws SQLException {
        if (DatabaseHelper.db.changePassword(this.accountId, newPassword)){
            // change this if else statement to show a message in the gui
            System.out.println("The password has been successfully changed");
            this.password = newPassword;
        } else {
            System.out.println("The password was not successfully changed");
        }
    }

    /**
     * Gets the Unique Account Id
     * @return the Account Id
     */
    public int getAccountId() {
        return this.accountId;
    }

    /**
     * Gets the Account Type
     * @return the Account Type
     */
    public String getAccountType() {
        return this.accountType;
    }
}
