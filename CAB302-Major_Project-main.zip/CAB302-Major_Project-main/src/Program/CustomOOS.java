package Program;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;

/**
 * A custom ObjectOutputStream class
 */
public class CustomOOS extends ObjectOutputStream {
    /**
     * Constructs a custom object output stream class
     * @param out the OutputStream
     * @throws IOException
     */
    public CustomOOS(OutputStream out) throws IOException {
        super(out);
        enableReplaceObject(true);
    }

    /**
     * Overrides a replaceObject method in default ObjectOutputStream java class.
     * Checks if an object is serializable.
     * @param obj the object to check
     * @return the object if it is serializable, skip the object if not
     * (doesn't create an error for a not serializable object in the code)
     */
    @Override
    protected Object replaceObject(Object obj) {
        if ((obj instanceof Serializable))
            return obj;
        System.err.println("Skipping serialization of "+obj);
        return null;
    }
}
