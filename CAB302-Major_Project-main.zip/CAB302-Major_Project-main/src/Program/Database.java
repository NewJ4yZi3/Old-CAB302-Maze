package Program;

import java.io.*;
import java.sql.*;

/**
 * Represents the designation to which all mazes should be stored
 */
public class Database implements Serializable {

    @Serial
    private static final long serialVersionUID = -2074579945759896507L;
    private static Connection connection;

    public Database() throws SQLException {
        connection = DriverManager.getConnection("jdbc:sqlite:cab302.db", "root", "asdfghjkl");
        createAllTables();
    }

    /**
     * Creates all the tables that stores all the data
     */
    private void createAllTables() throws SQLException {
        //-----statement to create the Accounts table
        String createAccountsTable = "CREATE TABLE if not exists Accounts (" +
                "Id INTEGER, " +
                "Username TEXT NOT NULL UNIQUE, " +
                "Password TEXT NOT NULL," +
                "Role TEXT NOT NULL," +
                "Account BLOB," +
                "PRIMARY KEY (Id AUTOINCREMENT)" +
                ");";

        // ----- statement to create the MazeFile Table
        String createMazeFileTable = "CREATE TABLE if not exists Maze_File (" +
                "Id INTEGER," +
                "Title TEXT NOT NULL," +
                "AuthorId INTEGER NOT NULL," +
                "Creation_date TEXT NOT NULL," +
                "Creation_time TEXT NOT NULL," +
                "Last_edit_date TEXT NOT NULL," +
                "Last_edit_time TEXT NOT NULL," +
                "Maze BLOB," +
                "MazeImage BLOB," +
                "SolutionImage BLOB," +
                "PRIMARY KEY(Id AUTOINCREMENT)," +
                "UNIQUE (Title, AuthorId)," +
                "FOREIGN KEY (AuthorId) REFERENCES Accounts(Id)" +
                ");";

        // create and execute all sql statements
        Statement statement = connection.createStatement();
        statement.execute(createAccountsTable);
        statement.execute(createMazeFileTable);
        // explicitly close the statement and the connection
        statement.close();
    }

    /**
     * closes the live connection to the database
     * @throws SQLException
     */
    public static void closeConnection() throws SQLException {
        connection.close();
    }

    /**
     * Adds a new record (user) in the Accounts table
     * @param username    the username of the account to be added
     * @param password    the password of the account to be added
     * @param accountType the type of the account to be added
     * @return true if the account was successfully added, otherwise false if no new record is added
     * @throws SQLException
     */
    public boolean addNewUser(String username, String password, String accountType) throws SQLException {
        boolean result;
        // create and execute the sql statement
        String addNewUser = "INSERT INTO Accounts (Username, Password, Role) VALUES (?, ?, ?)";
        PreparedStatement statement = connection.prepareStatement(addNewUser);
        statement.clearParameters();
        statement.setString(1, username);
        statement.setString(2, password);
        statement.setString(3, accountType);
        result = statement.executeUpdate() == 1;
        // explicitly close the statement and the connection
        statement.close();
        return result;
    }

    /**
     * Adds the Account instance to the row of the Account
     * @param obj the Account object
     * @param AccountId the unique Id of the Account
     * @throws IOException
     * @throws SQLException
     */
    public void addAccountObj(Account obj, int AccountId) throws IOException, SQLException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(obj);
        // serialize the employee object into a byte array
        byte[] accountAsBytes = baos.toByteArray();
        PreparedStatement pstmt = connection.prepareStatement("UPDATE Accounts SET Account = ? WHERE Id = ?");
        ByteArrayInputStream bais = new ByteArrayInputStream(accountAsBytes);
        // bind our byte array  to the emp column
        pstmt.clearParameters();
        pstmt.setBinaryStream(1, bais, accountAsBytes.length);
        pstmt.setInt(2, AccountId);
        pstmt.executeUpdate();
        pstmt.close();
    }

    /**
     * Retrieve the Account instance of a specified Account
     * @param AccountId the unique Id of the Account to retrieve
     * @return the Account instance
     * @throws SQLException
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public Account getAccountObj(int AccountId) throws SQLException, IOException, ClassNotFoundException {
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT Account FROM Accounts WHERE Id =" + AccountId);
        rs.next();
        // fetch the serialized object to a byte array
        byte[] st = (byte[]) rs.getObject(1);
        ByteArrayInputStream baip = new ByteArrayInputStream(st);
        ObjectInputStream ois = new ObjectInputStream(baip);
        // re-create the object
        Account obj = (Account) ois.readObject();
        stmt.close();
        rs.close();
        return obj;
    }

    /**
     * Checks the database if there is a user in the Accounts table that matches a supplied username and password
     * @param username the username to be matched
     * @return true if there is exactly 1 user that matched the criteria, otherwise false if there is 0 or more than 1 user that matched the criteria
     * @throws SQLException
     */
    public boolean checkExistingUser(String username) throws SQLException {
        boolean result;
        // prepare the sql statement
        String CheckUsernameAndPassword = "SELECT EXISTS(SELECT 1 FROM Accounts WHERE Username ='" +
                username + "' LIMIT 1)";
        // create and execute the sql statement
        Statement statement = connection.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
        ResultSet resultSet = statement.executeQuery(CheckUsernameAndPassword);
        // check the result
        if (resultSet.next()) {
            // if there is one row matching the supplied username and password, the user does exist in the database
            result = resultSet.getInt(1) == 1;
        } else result = false;
        //explicitly close the statement(s)
        resultSet.close();
        statement.close();
        return result;
    }

    /**
     * Gets the Unique Account ID based on the database
     * @param username the username of the Account
     * @return the Account ID
     * @throws SQLException
     */
    public int getId(String username) throws SQLException {
        int AccountId;
        // create and execute the sql statement
        String getId = "SELECT * FROM Accounts WHERE Username ='" +
                username + "'";
        Statement statement = connection.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
        ResultSet result = statement.executeQuery(getId);
        // check the result
        if (result.next()) {
            AccountId = result.getInt(1);
        } else AccountId = 0;
        // explicitly close the statement and the connection
        result.close();
        statement.close();
        return AccountId;
    }

    /**
     * Changes the username of an account in the accounts table
     * @param accountId   the unique id of the account
     * @param newUsername the new username of the account
     * @return true if the change was successfully made in the database, otherwise false if the change was not successfully made
     * @throws SQLException
     */
    public boolean changeUsername(int accountId, String newUsername) throws SQLException {
        boolean result;
        // create and execute the sql statement
        String changeUsername = "UPDATE Accounts SET Username = ? WHERE Id = ?";
        PreparedStatement statement = connection.prepareStatement(changeUsername);
        statement.clearParameters();
        statement.setString(1, newUsername);
        statement.setInt(2, accountId);
        result = statement.executeUpdate() == 1;
        // explicitly close the statement and connection
        statement.close();
        return result;
    }

    /**
     * Changes the password of an account in the accounts table
     * @param accountId   the unique id of the account
     * @param newPassword the new username of the account
     * @return true if the change was successfully made in the database, otherwise false if the change was not successfully made
     * @throws SQLException
     */
    public boolean changePassword(int accountId, String newPassword) throws SQLException {
        boolean result;
        // create and execute the sql statement
        String changePassword = "UPDATE Accounts SET Password = ? WHERE Id = ?";
        PreparedStatement statement = connection.prepareStatement(changePassword);
        statement.clearParameters();
        statement.setString(1, newPassword);
        statement.setInt(2, accountId);
        result = statement.executeUpdate() == 1;
        // explicitly close the statement and connection
        statement.close();
        return result;
    }

    /**
     * Saves a Maze in the Maze_File table of the database (Adds a new one if it doesn't exist; overwrites MazeObject if it does exist)
     * @param Title    the title of the new Maze to be added
     * @param AuthorId the AccountId of the Author of the Maze
     * @throws SQLException
     */
    public void saveMazeFile(String Title, int AuthorId, MazeObject Maze) throws SQLException, IOException {
        // variables for storing the date and time
        long millis = System.currentTimeMillis();
        String currentDate = new Date(millis).toString();
        String currentTime = new Time(millis).toString();
        boolean changeSuccess;

        ByteArrayOutputStream baOStream = new ByteArrayOutputStream();
        CustomOOS objOStream = new CustomOOS(baOStream);
        objOStream.writeObject(Maze);
        objOStream.flush();
        byte[] MazeAsBytes = baOStream.toByteArray();
        ByteArrayInputStream baisMaze = new ByteArrayInputStream(MazeAsBytes);
        ByteArrayInputStream baisMazeCopy = new ByteArrayInputStream(MazeAsBytes);

        byte[] imageAsBytes = MazeImage.convertMazeImage(MazeImage.createMazeImage(Maze.getLayeredPane()), FileType.JPEG);
        ByteArrayInputStream baisMazeImage = new ByteArrayInputStream(imageAsBytes);
        ByteArrayInputStream baisMazeImageCopy = new ByteArrayInputStream(imageAsBytes);
        byte[] solutionAsBytes = MazeImage.convertMazeImage(MazeImage.createSolutionImage(Maze, Maze.getLayeredPane()), FileType.JPEG);
        ByteArrayInputStream baisSolutionImage = new ByteArrayInputStream(solutionAsBytes);
        ByteArrayInputStream baisSolutionImageCopy = new ByteArrayInputStream(solutionAsBytes);

        // create and execute the sql statement
        String saveMazeFile = "INSERT INTO Maze_File (Title, AuthorId, Creation_date, Creation_time, " +
                "Last_edit_date, Last_edit_time, Maze, MazeImage, SolutionImage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)" +
                "ON CONFLICT(Title, AuthorId) DO UPDATE SET Last_edit_date = ?, Last_edit_time = ?, Maze = ?, MazeImage = ?, SolutionImage = ?";
        PreparedStatement statement = connection.prepareStatement(saveMazeFile);
        statement.clearParameters();
        statement.setString(1, Title);
        statement.setInt(2, AuthorId);
        statement.setString(3, currentDate);
        statement.setString(4, currentTime);
        statement.setString(5, currentDate);
        statement.setString(6, currentTime);
        statement.setBinaryStream(7, baisMaze, MazeAsBytes.length);
        statement.setBinaryStream(8, baisMazeImage, imageAsBytes.length);
        statement.setBinaryStream(9, baisSolutionImage, solutionAsBytes.length);
        statement.setString(10, currentDate);
        statement.setString(11, currentTime);
        statement.setBinaryStream(12, baisMazeCopy, MazeAsBytes.length);
        statement.setBinaryStream(13, baisMazeImageCopy, imageAsBytes.length);
        statement.setBinaryStream(14, baisSolutionImageCopy, solutionAsBytes.length);
        changeSuccess = statement.executeUpdate() == 1;
        // explicitly close the statement and the connection
        statement.close();
    }

    /**
     * Gets the MazeObject from a record in the Maze_File table
     * @param mazeId the uniqueId of the Maze from the database
     * @return the MazeObject instance
     * @throws SQLException
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public MazeObject getMazeObj(int mazeId) throws SQLException, IOException, ClassNotFoundException {
        Statement stmt = connection.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT Maze FROM Maze_File WHERE Id =" + mazeId);
        rs.next();
        // fetch the serialized object to a byte array
        byte[] st = (byte[]) rs.getObject(1);
        ByteArrayInputStream baip = new ByteArrayInputStream(st);
        ObjectInputStream ois = new ObjectInputStream(baip);
        // re-create the object
        MazeObject obj = (MazeObject) ois.readObject();
        stmt.close();
        rs.close();
        return obj;
    }

    /**
     * Checks if a maze that is going to be created already exists in the database
     * @param Title the title of the maze to be created
     * @param AuthorId the unique account id of the current mazeDesigner
     * @return true if the maze already exists
     * @throws SQLException
     */
    public boolean checkExistingMaze(String Title, int AuthorId) throws SQLException {
        boolean result;
        Statement s = connection.createStatement();
        ResultSet rs = s.executeQuery("SELECT Count(*) FROM Maze_file WHERE Title = '" + Title + "' and AuthorId = " + AuthorId);
        rs.next();
        if (rs.getInt(1) == 1){
            result = true;
        }
        else result = false;
        rs.close();
        s.close();
        return result;
    }

    /**
     * Get the buffered images of the as bytes
     * @param mazeSnipType either "MazeImage" or "SolutionImage"
     * @param title the title of the Maze
     * @return the buffered image as bytes
     * @throws SQLException
     * @throws IOException
     */
    public byte[] getMazeSnipAsBytes(String mazeSnipType, String title) throws SQLException, IOException {
        // note: IDK if this works
        Statement s = connection.createStatement();
        ResultSet rs = s.executeQuery("SELECT " + mazeSnipType + " FROM Maze_file WHERE Title = " + title);
        rs.next();
        byte[] st = (byte[]) rs.getObject(1);
        rs.close();
        s.close();
        return st;
    }

    /**
     * Gets the unique Maze id from the database
     * @param mazeTitle the title of the maze
     * @param authorId the unique Account Id of the author of the maze
     * @return the unique Maze Id
     * @throws SQLException
     */
    public int getMazeFileId(String mazeTitle, int authorId) throws SQLException {
        int mazeId;
        // create and execute the sql statement
        String getId = "SELECT * FROM Maze_File WHERE Title ='" +
                mazeTitle + "' and AuthorId ='" + authorId + "'";
        Statement statement = connection.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
        ResultSet result = statement.executeQuery(getId);
        // check the result
        if (result.next()) {
            mazeId = result.getInt(1);
        } else mazeId = 0;
        // explicitly close the statement and the connection
        result.close();
        statement.close();
        return mazeId;
    }

    /**
     * Gets all the mazes from the database and the username of each maze
     * @return the Result Set of all the Mazes
     * @throws SQLException
     */
    public ResultSet getMazes() throws SQLException {
        // create and execute the sql statement
        String getMazes = "SELECT \"Title\", \"Username\", \"Creation_date\", \"Creation_time\", \"Last_edit_date\", \"Last_edit_time\"" +
                "FROM Maze_File, Accounts WHERE Maze_File.AuthorId = Accounts.Id";
        Statement s = connection.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
        s.close();
        return s.executeQuery(getMazes);
    }

    /**
     * Reads the Result Set of all the Mazes from the database and populates a multidimensional string array with the values from the Result Set
     * @param rs the result set
     * @param rows the number of Results in the Result Set
     * @return a multidimensional string array with the values of the Result Set
     * @throws SQLException
     */
    public String[][] readResultSet(ResultSet rs, int rows) throws SQLException {
        // put the contents of the result set in an object array
        int col = 6;
        String[][] data = new String[rows][col];
        for (int r = 0; r<rows; r++) {
            if (rs.next()) {
                String[] metaData = {
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                };
                System.arraycopy(metaData, 0, data[r], 0, col);
            }
        }
        rs.close();
        return data;
    }

    /**
     * Counts the number of mazes in the database
     * @return int value of the total count of the result set.
     * @throws SQLException
     */
    public int countResultSet() throws SQLException {
        int count;
        // create and execute the sql statement
        String getMazes = "SELECT \"Title\", \"Username\", \"Creation_date\", \"Creation_time\", \"Last_edit_date\", \"Last_edit_time\"" +
                "FROM Maze_File, Accounts WHERE Maze_File.AuthorId = Accounts.Id";
        String getCount = "SELECT count(*) FROM (" + getMazes + ")";
        Statement statement = connection.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
        ResultSet result = statement.executeQuery(getCount);
        // check the result
        count = result.getInt(1);
        // explicitly close the statement and the connection
        result.close();
        statement.close();
        return count;
    }
}
