package Program;

import java.sql.SQLException;

public class DatabaseHelper {
    public static Database db;

    static {
        try {
            db = new Database();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
