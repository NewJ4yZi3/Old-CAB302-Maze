package Program;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Represents a class for Exporting mazes
 */
public class Export {

    /**
     * Method for a save dialog returns path.
     * @param s String of the initial directory for the file chooser if required.
     * @return String value of the path for saving an image.
     */
    public static Path getSavePath(String s) {
        JFileChooser myFileChooser= s == null ? new JFileChooser() : new JFileChooser(s);
        myFileChooser.setDialogTitle("Choose save location");
        myFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int returnVal= myFileChooser.showSaveDialog(null);
        if (returnVal != JFileChooser.APPROVE_OPTION) return null;
        return myFileChooser.getSelectedFile().toPath();
    }

    /**
     * Method to write images to local directory.
     * @param names An array list of the string names of the images.
     * @param path The path to a local directory.
     * @param res The requested resolution of the image.
     */
    public static void writeToLocal(ArrayList<String> names, Path path, Resolution res) {
        FileType fileType = FileType.JPEG;
        for (String s : names) {
            String name = s.replaceAll("\\s+","");
            Path mazePath = Path.of(path + "\\" + name + "." + fileType.getFileType().toLowerCase() );
            Path solutionPath = Path.of(path + "\\" + name + "solution." + fileType.getFileType().toLowerCase());
            byte[] mazeImage;
            byte[] solutionImage;
            BufferedImage buffMaze = null;
            BufferedImage buffSolution = null;
            BufferedImage newBuffMaze = null;
            BufferedImage newBuffSolution = null;
            try {
                mazeImage = DatabaseHelper.db.getMazeSnipAsBytes("MazeImage",("\"" + s + "\""));
                solutionImage = DatabaseHelper.db.getMazeSnipAsBytes("SolutionImage", ("\"" + s + "\""));
                InputStream mazeInputStream = new ByteArrayInputStream(mazeImage);
                InputStream solutionInputStream = new ByteArrayInputStream(solutionImage);
                buffMaze = ImageIO.read(mazeInputStream);
                buffSolution = ImageIO.read(solutionInputStream);
                newBuffMaze = new BufferedImage(res.getWidth(), res.getHeight(), BufferedImage.TYPE_INT_RGB);
                newBuffSolution = new BufferedImage(res.getWidth(), res.getHeight(), BufferedImage.TYPE_INT_RGB);
                Graphics gMaze = newBuffMaze.createGraphics();
                Graphics gSolution = newBuffSolution.createGraphics();
                gMaze.drawImage(buffMaze, 0, 0, res.getWidth(), res.getHeight(), null);
                gSolution.drawImage(buffSolution, 0, 0, res.getWidth(), res.getHeight(), null);
                gMaze.dispose();
                gSolution.dispose();
            } catch (SQLException | IOException ex) {
                ex.printStackTrace();
            }
            try {
                MazeImage.writeImage(newBuffMaze, fileType, mazePath);
                MazeImage.writeImage(newBuffSolution, fileType, solutionPath);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        names.clear();
    }
}