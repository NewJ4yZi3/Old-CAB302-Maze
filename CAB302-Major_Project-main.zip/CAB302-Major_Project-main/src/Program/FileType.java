package Program;

/**
 * Represents an enumeration for image file types
 */
public enum FileType {
    JPEG("JPEG"), PNG("PNG"), PDF("PDF"), JPG("JPG");
    // any other file types that can output as an image or similar

    private final String fileType;

    FileType(String fileType) {
        this.fileType = fileType;
    }

    public String getFileType() {return fileType;}
}
