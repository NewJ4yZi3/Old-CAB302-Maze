package Program;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.io.*;
import java.nio.file.Path;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

public class GUI extends WindowAdapter implements ActionListener {

    private final Database db = DatabaseHelper.db;
    private Account currentUser;
    private MazeDesigner currentMazeDesigner;
    private Size size;
    private HashMap<String,String> imagePaths;
    private JLabel imageNameLabel;
    private JLabel startImageLabel;
    private JLabel endImageLabel;
    private Resolution resolution;

    // maze creation text fields
    private JTextField titleField;

    // account creation text fields
    private JTextField userField;
    private JPasswordField passwordField;
    private ButtonGroup typeGroup;

    // login text fields
    private JTextField lUserField;
    private JPasswordField lPasswordField;

    /**
     * Constructs a JFrame to hold everything together
     * @param width the width of the frame
     * @param height the height of the frame
     * @param title the title of the frame
     * @return the JFrame
     */
    private JFrame createFrame(int width, int height, String title){
        JFrame frame = new JFrame();
        frame.setSize(width,height);
        frame.setLayout(new BorderLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle(title);
        frame.setLocationRelativeTo(null);

        return frame;
    }

    /**
     * Creates a JPanel
     * @return the JPanel
     */
    private JPanel createPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);

        return panel;
    }

    /**
     * Creates a JLabel
     * @param width the width of the label
     * @param height the height of the label
     * @param title the title of the label
     * @return the JLabel
     */
    private JLabel createLabel(int width, int height, String title) {
        JLabel label = new JLabel(title);
        label.setPreferredSize(new Dimension(width, height));
        label.setHorizontalAlignment(SwingConstants.CENTER);

        return label;
    }

    /**
     * Creates a JButton
     * @param title the title of the button
     * @return the JButton
     */
    private JButton createButton(String title) {
        JButton button = new JButton(title);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.addActionListener(this);

        return button;
    }

    /**
     * Creates a GridBagConstraints to put on a Panel
     * @param panel the panel to apply the grid constraints to
     * @return the GridBagConstraints
     */
    private GridBagConstraints setupGridBag(JPanel panel) {
        GridBagLayout layout = new GridBagLayout();
        panel.setLayout(layout);

        return new GridBagConstraints();
    }

    /**
     * Adds a component to a panel within some constraints
     * @param jp the panel
     * @param c the component
     * @param constraints the GridBagConstraints
     * @param x
     * @param y
     * @param w
     */
    private void addToPanel(JPanel jp, Component c, GridBagConstraints constraints, int x, int y, int w) {
        constraints.fill = GridBagConstraints.NONE;
        constraints.anchor = GridBagConstraints.LINE_START;
        constraints.weightx = 0;
        constraints.weighty = 0;
        constraints.gridx = x;
        constraints.gridy = y;
        constraints.gridwidth = w;
        constraints.gridheight = 1;

        jp.add(c, constraints);
    }

    /**
     * The listener method for button presses in the main GUI
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e) {
        String btnString = e.getActionCommand();
        Component button = (Component) e.getSource();
        JFrame window = (JFrame) SwingUtilities.windowForComponent( button );
        if (btnString.equals("Select Logo for Import") || btnString.equals("Select Start Icon") || btnString.equals("Select Finish Icon")) {
            JFileChooser ImageSelector = new JFileChooser();
            ImageSelector.setCurrentDirectory(new File(".\\img"));
            ImageSelector.addChoosableFileFilter(new ImageFilter());
            ImageSelector.setAcceptAllFileFilterUsed(false);
            int option = ImageSelector.showOpenDialog(window);
            if(option == JFileChooser.APPROVE_OPTION){
                File file = ImageSelector.getSelectedFile();
                switch (btnString) {
                    case "Select Logo for Import" -> {
                        imagePaths.put("Logo", file.getPath());
                        imageNameLabel.setText(file.getName());
                    }
                    case "Select Start Icon" -> {
                        imagePaths.put("Start", file.getPath());
                        startImageLabel.setText(file.getName());
                    }
                    case "Select Finish Icon" -> {
                        imagePaths.put("Finish", file.getPath());
                        endImageLabel.setText(file.getName());
                    }
                }

            }
        }

        if (btnString.equals("Low")) {
            resolution = Resolution.LOW;
        }
        if (btnString.equals("Medium")) {
            resolution = Resolution.MED;
        }
        if (btnString.equals("High")) {
            resolution = Resolution.HIGH;
        }

        if (btnString.equals("Small")) {
            size = Size.SMALL;
        }
        if (btnString.equals("Medium")) {
            size = Size.MEDIUM;
        }
        if (btnString.equals("Large")) {
            size = Size.LARGE;
        }
        if (btnString.equals("XLarge")) {
            size = Size.XLARGE;
        }
        if (btnString.equals("Login")) {
            String username = lUserField.getText();
            String password = String.valueOf(lPasswordField.getPassword());

            try {
                if (db.checkExistingUser(username)){
                    int currentUserId = db.getId(username);
                    currentUser = db.getAccountObj(currentUserId);
                    if (currentUser instanceof MazeDesigner){
                        currentMazeDesigner = (MazeDesigner) currentUser;
                    }
                    else if (currentUser instanceof Publisher){
                        Publisher currentPublisher = (Publisher) currentUser;
                    }
                    window.dispose();
                    createMainMenuWindow();
                }
                else {
                    createErrorDialog("This account doesn't exists. \n" +
                            "Please create an account.");
                    lUserField.setText("");
                    lPasswordField.setText("");
                }
            } catch (SQLException | IOException | ClassNotFoundException ex) {
                ex.printStackTrace();
            }
        }
        if (btnString.equals("Create Account")) {
            createAccountWindow();
        }
        if (btnString.equals("Register Account")) {
            String username = userField.getText();
            String password = String.valueOf(passwordField.getPassword());
            // check if the credentials entered already exists for an existing user
            try {
                if (db.checkExistingUser(username)){
                    createErrorDialog("This account already exists. \n" +
                            "Please Register with a different Username.");
                    userField.setText("");
                    passwordField.setText("");
                }
                else {
                    // checking the contents of the username and password
                    if (!(username.matches("(.+)"))) {
                        createErrorDialog("The username cannot be blank.");
                    } else if (!(password.matches("(.*)[0-9]+(.*)"))) {
                        createErrorDialog("The password must contain at least one number.");
                    } else if (!(password.matches("(.*)[A-Z]+(.*)"))) {
                        createErrorDialog("The password must contain at least one capital letter.");
                    } else if (!(password.matches("(.*)[a-z]+(.*)"))) {
                        createErrorDialog("The password must contain at least one lower case letter.");
                    } else if (!(password.matches(".{8,}"))) {
                        createErrorDialog("The password must contain at least 8 characters.");
                    } else { // the password has passed the requirements above
                        if (Objects.equals(typeGroup.getSelection().getActionCommand(), "mazeDesigner")) {
                            try {
                                Account mazeDesigner = new MazeDesigner(username, password);
                                mazeDesigner.addAccountObj();
                            } catch (SQLException | IOException ex) {
                                ex.printStackTrace();
                            }
                            window.dispose();
                            createSuccessDialog();
                        } else if (Objects.equals(typeGroup.getSelection().getActionCommand(), "publisher")) {
                            try {
                                Account publisher = new Publisher(username, password);
                                publisher.addAccountObj();
                            } catch (SQLException | IOException ex) {
                                ex.printStackTrace();
                            }
                            window.dispose();
                            createSuccessDialog();
                        }
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        if (btnString.equals("Cancel")) {
            window.dispose();
            if (window.getTitle().equals("Maze Creator - Setup")) {
                createMainMenuWindow();
            }
        }
        if (btnString.equals("Back")) {
            window.dispose();
        }
        if (btnString.equals("Exit")) {
            try {
                Database.closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            System.exit(0);
        }
        if (btnString.equals("Create A Maze")) {
            window.dispose();
            createSetupWindow();
        }
        if (btnString.equals("Edit A Maze")) {
            try {
                createEditWindow();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        if (btnString.equals("Export Maze")) {
            try {
                createExportWindow();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        if (btnString.equals("Create Manually")) {
            String mazeTitle = titleField.getText();
            if (size == null){
                size = Size.SMALL;
            }
            try {
                if (db.checkExistingMaze(mazeTitle, currentMazeDesigner.getAccountId())){
                    createErrorDialog("There is already an existing maze with the same title." +
                            "Please enter a different title.");
                }
                else {
                    Maze mazeFile = currentMazeDesigner.createMazeFile(size, mazeTitle, imagePaths, false);
                    currentMazeDesigner.addListeners(mazeFile.getMaze());
                    mazeFile.getMaze().solveButton.setSelected(false);
                }
            } catch (SQLException | ClassNotFoundException | IOException ex) {
                ex.printStackTrace();
            }
        }
        if (btnString.equals("Auto Generate")) {
            String mazeTitle = titleField.getText();
            if (size == null){
                size = Size.SMALL;
            }
            try {
                if (db.checkExistingMaze(mazeTitle, currentMazeDesigner.getAccountId())){
                    createErrorDialog("There is already an existing maze with the same title." +
                            "Please enter a different title.");
                }
                else {
                    Maze mazeFile = currentMazeDesigner.createMazeFile(size, mazeTitle, imagePaths, true);
                    currentMazeDesigner.addListeners(mazeFile.getMaze());
                    mazeFile.getMaze().solveButton.setSelected(false);
                }
            } catch (SQLException | ClassNotFoundException | IOException ex) {
                ex.printStackTrace();
            }
        }
        if (btnString.equals("Edit")){
            try {
                int theRow = mazeTable.getSelectedRow();
                int selectedRow = mazeTable.convertRowIndexToModel(theRow);
                String selectedMazeTitle = mazeTable.getModel().getValueAt(selectedRow, 0).toString();
                String selectedMazeUsername = mazeTable.getModel().getValueAt(selectedRow, 1).toString();
                if (Objects.equals(selectedMazeUsername, currentMazeDesigner.getUsername())){
                    MazeObject currentMaze = currentMazeDesigner.editMaze(selectedMazeTitle);
                    currentMaze.solveButton.setSelected(false);
                    currentMaze.setVisible(true);
                } else {
                    createErrorDialog("You are not authorised to make changes to this Maze. \n" +
                            "Please choose another Maze");
                    // this means the current logged in Maze Designer is not the author of the maze they are trying to edit
                    // should we still let them view the maze (read only) or not bother?
                }
            } catch (SQLException | IOException | ClassNotFoundException ex) {
                ex.printStackTrace();
            }
        }

        if (btnString.equals("Export")) {
            ArrayList<String> names = new ArrayList<>();
            int column = 0;
            for (int row : mazeTable.getSelectedRows()) {
                int theRealRow = mazeTable.convertRowIndexToModel(row);
                String value = (mazeTable.getModel().getValueAt(theRealRow, column).toString());
                names.add(value);
            }
            Path path = Export.getSavePath(null);
            if (resolution == null) {
                resolution = Resolution.LOW;
            }
            Export.writeToLocal(names, path, resolution);

        }
    }

    /**
     * The method to call in the Main to run the program
     */
    public void runGUI() {
        JFrame openingFrame = createFrame(600,600, "Maze Creator");
        openingFrame.setUndecorated(true);
        openingFrame.getRootPane().setWindowDecorationStyle(JRootPane.NONE);

        JLabel logoLabel = new JLabel(new ImageIcon("img/Logo.png"));

        openingFrame.add(logoLabel, BorderLayout.CENTER);

        Timer closeTimer = new Timer(4000, evt -> {
            openingFrame.dispose();
            createLoginWindow();
        });
        closeTimer.setRepeats(false);

        openingFrame.setVisible(true);
        closeTimer.start();
    }

    /**
     * Creates the Login Window
     */
    private void createLoginWindow() {
        JFrame loginFrame = createFrame(400,200,"Maze Creator - Login");

        JPanel loginPanel = createPanel();
        JPanel buttonPanel = createPanel();
        JLabel userLabel = createLabel(80,30,"Username: ");
        JLabel passwordLabel = createLabel(80,30,"Password: ");
        lUserField = new JTextField(10);
        lPasswordField = new JPasswordField(10);

        JButton loginButton = createButton("Login");
        JButton accountButton = createButton("Create Account");
        JButton exitButton = createButton("Exit");

        buttonPanel.setLayout(new FlowLayout());

        buttonPanel.add(loginButton);
        buttonPanel.add(accountButton);
        buttonPanel.add(exitButton);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(0,0,20,0));

        GridBagConstraints constraints = setupGridBag(loginPanel);

        addToPanel(loginPanel, userLabel, constraints,1,1,2);
        addToPanel(loginPanel, lUserField, constraints,3,1,5);
        addToPanel(loginPanel, passwordLabel, constraints,1,2,2);
        addToPanel(loginPanel, lPasswordField, constraints,3,2,5);

        loginFrame.add(buttonPanel, "South");

        loginFrame.add(loginPanel, "Center");

        loginFrame.setVisible(true);
    }

    /**
     * Creates the window for registering an account
     */
    private void createAccountWindow() {
        JFrame accountFrame = createFrame(500, 300, "Maze Creator - Create Account");

        JPanel accountPanel = createPanel();
        JPanel buttonPanel = createPanel();
        buttonPanel.setLayout(new FlowLayout());

        JLabel userLabel = createLabel(80,30,"Username: ");
        userLabel.setHorizontalAlignment(SwingConstants.LEADING);
        JLabel passwordLabel = createLabel(80,30,"Password: ");
        passwordLabel.setHorizontalAlignment(SwingConstants.LEADING);
        JLabel accountTypeLabel = createLabel(100,30,"Account Type: ");
        accountTypeLabel.setHorizontalAlignment(SwingConstants.LEADING);

        userField = new JTextField(10);
        passwordField = new JPasswordField(10);

        JRadioButton designerButton = new JRadioButton("Maze Designer");
        designerButton.setActionCommand("mazeDesigner");

        designerButton.setSelected(true);   // the default selected account type is a maze designer
                                            // avoids the issue of: if a user has not selected an account type

        JRadioButton publisherButton = new JRadioButton("Publisher");
        publisherButton.setActionCommand("publisher");

        typeGroup = new ButtonGroup();
        typeGroup.add(designerButton);
        typeGroup.add(publisherButton);

        JButton createAccountButton = createButton("Register Account");
        JButton cancelButton = createButton("Cancel");

        buttonPanel.add(createAccountButton);
        buttonPanel.add(cancelButton);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10,0,20,0));

        GridBagConstraints constraints = setupGridBag(accountPanel);
        constraints.anchor = GridBagConstraints.LINE_START;

        addToPanel(accountPanel, userLabel, constraints,1,2,2);
        addToPanel(accountPanel, userField, constraints,3,2,5);
        addToPanel(accountPanel, passwordLabel, constraints,1,3,2);
        addToPanel(accountPanel, passwordField, constraints,3,3,5);
        addToPanel(accountPanel, accountTypeLabel, constraints,1,4,6);
        addToPanel(accountPanel, designerButton, constraints,2,5,2);
        addToPanel(accountPanel, publisherButton, constraints,4,5,2);

        accountFrame.add(buttonPanel, "South");

        accountFrame.add(accountPanel, "Center");

        accountFrame.setVisible(true);
    }

    /**
     * Creates the main window for choosing to create/edit a maze (for mazeDesigners) or export (for publishers)
     */
    private void createMainMenuWindow() {
        JFrame mainMenuFrame = createFrame(500,300,"Maze Creator - Main Menu");

        JPanel buttonPanel = createPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.PAGE_AXIS));
        JPanel labelPanel = createPanel();

        JLabel loggedPanel = createLabel(80,40,"Logged in as: ");
        JLabel accountPanel = createLabel(150,40, currentUser.getUsername() + " [" + currentUser.getAccountType() + "]");
        LineBorder line = new LineBorder(Color.gray, 1, true);
        accountPanel.setBorder(line);

        JButton createMazeButton = createButton("Create A Maze");
        JButton editButton = createButton("Edit A Maze");
        JButton exportButton = createButton("Export Maze");
        JButton exitButton = createButton("Exit");
        if (currentUser instanceof MazeDesigner){
            exportButton.setEnabled(false);
        }
        else if (currentUser instanceof Publisher){
            createMazeButton.setEnabled(false);
            editButton.setEnabled(false);
        }

        buttonPanel.add(createMazeButton);
        createMazeButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonPanel.add(Box.createRigidArea(new Dimension(0,4)));
        buttonPanel.add(editButton);
        editButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonPanel.add(Box.createRigidArea(new Dimension(0,4)));
        buttonPanel.add(exportButton);
        exportButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonPanel.add(Box.createRigidArea(new Dimension(0,20)));
        buttonPanel.add(exitButton);
        exitButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10,10,20,10));

        mainMenuFrame.add(labelPanel, BorderLayout.CENTER);
        mainMenuFrame.add(buttonPanel, BorderLayout.SOUTH);

        GridBagConstraints constraints = setupGridBag(labelPanel);

        addToPanel(labelPanel, loggedPanel, constraints,2,2,3);
        addToPanel(labelPanel, accountPanel, constraints,6,2,5);

        labelPanel.setBorder(BorderFactory.createEmptyBorder(20,0,10,0));

        mainMenuFrame.setVisible(true);
    }

    /**
     * Creates the first window for creating/generating a maze
     */
    private void createSetupWindow() {
        JFrame setupFrame = createFrame(500,400,"Maze Creator - Setup");

        JPanel buttonPanel = createPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.LINE_AXIS));
        JPanel selectPanel = createPanel();
        selectPanel.setLayout(new BoxLayout(selectPanel, BoxLayout.PAGE_AXIS));
        JPanel titlePanel = createPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.LINE_AXIS));
        JPanel sizePanel = createPanel();

        titleField = new JTextField(10);
        imagePaths = new HashMap<>();

        JLabel titleLabel = createLabel(80,40,"Title: ");
        JLabel logoLabel = createLabel(100,40,"Logo (Select from folder): ");
        JLabel sizeLabel = createLabel(80,40,"Size: ");

        JButton selectImageButton = new JButton("Select Logo for Import");
        JButton selectStartImageButton = new JButton("Select Start Icon");
        JButton selectEndImageButton = new JButton("Select Finish Icon");
        imageNameLabel = new JLabel();
        startImageLabel = new JLabel();
        endImageLabel = new JLabel();
        selectImageButton.addActionListener(this);
        selectStartImageButton.addActionListener(this);
        selectEndImageButton.addActionListener(this);

        JRadioButton sml = new JRadioButton("Small");
        sml.setSelected(true); // Default maze size selected is small
                               // avoids the issue of: if there is no size selected

        sml.addActionListener(this);
        JRadioButton med = new JRadioButton("Medium");
        med.addActionListener(this);
        JRadioButton lrg = new JRadioButton("Large");
        lrg.addActionListener(this);
        JRadioButton xLrg = new JRadioButton("XLarge");
        xLrg.addActionListener(this);

        ButtonGroup sizeGroup = new ButtonGroup();
        sizeGroup.add(sml);
        sizeGroup.add(med);
        sizeGroup.add(lrg);
        sizeGroup.add(xLrg);

        JButton autoGenerateButton = createButton("Auto Generate");
        JButton createManuallyButton = createButton("Create Manually");
        JButton cancelButton = createButton("Cancel");

        buttonPanel.add(autoGenerateButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(5,0)));
        buttonPanel.add(createManuallyButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(40,0)));
        buttonPanel.add(cancelButton);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10,50,20,10));

        titlePanel.add(titleLabel);
        titlePanel.add(Box.createRigidArea(new Dimension(2,0)));
        titlePanel.add(titleField);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(10,20,20,10));

        selectPanel.add(logoLabel);
        selectPanel.add(Box.createRigidArea(new Dimension(0,5)));
        selectPanel.add(selectImageButton);
        selectPanel.add(Box.createRigidArea(new Dimension(0,5)));
        selectPanel.add(imageNameLabel);
        selectPanel.add(Box.createRigidArea(new Dimension(0,5)));
        selectPanel.add(selectStartImageButton);
        selectPanel.add(Box.createRigidArea(new Dimension(0,5)));
        selectPanel.add(startImageLabel);
        selectPanel.add(Box.createRigidArea(new Dimension(0,5)));
        selectPanel.add(selectEndImageButton);
        selectPanel.add(Box.createRigidArea(new Dimension(0,5)));
        selectPanel.add(endImageLabel);
        selectPanel.setBorder(BorderFactory.createEmptyBorder(10,0,10,20));

        setupFrame.add(sizePanel, BorderLayout.CENTER);
        setupFrame.add(buttonPanel, BorderLayout.SOUTH);
        setupFrame.add(titlePanel, BorderLayout.NORTH);
        setupFrame.add(selectPanel, BorderLayout.EAST);

        GridBagConstraints constraints = setupGridBag(sizePanel);
        constraints.anchor = GridBagConstraints.LINE_START;

        addToPanel(sizePanel, sizeLabel,constraints,1,1,1);
        addToPanel(sizePanel, sml,constraints,2,3,1);
        addToPanel(sizePanel, med,constraints,2,4,1);
        addToPanel(sizePanel, lrg,constraints,2,5,1);
        addToPanel(sizePanel, xLrg,constraints,2,6,1);

        setupFrame.setVisible(true);
    }

    private JTable mazeTable;

    /**
     * Creates the export window for publishers
     * @throws SQLException
     */
    private void createExportWindow() throws SQLException {
        JFrame exportFrame = createFrame(500,620,"Maze Creator - Export");

        JPanel selectMazesPanel = createPanel();
        selectMazesPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        JPanel selectResolutionPanel = createPanel();
        selectResolutionPanel.setLayout(new FlowLayout(FlowLayout.LEADING));
        JPanel buttonPanel = createPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.TRAILING));

        JButton exportButton = createButton("Export");
        JButton returnButton = createButton("Back");

        buttonPanel.add(exportButton);
        exportButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
        buttonPanel.add(returnButton);
        returnButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10,250,20,20));

        JLabel selectResolutionLabel = createLabel(200,80,"Select Resolution: ");

        JRadioButton lowRes = new JRadioButton("Low");
        lowRes.setSelected(true);
        lowRes.addActionListener(this);
        JRadioButton mediumRes = new JRadioButton("Medium");
        mediumRes.addActionListener(this);
        JRadioButton highRes = new JRadioButton("High");
        highRes.addActionListener(this);

        ButtonGroup resGroup = new ButtonGroup();
        resGroup.add(lowRes);
        resGroup.add(mediumRes);
        resGroup.add(highRes);

        selectResolutionPanel.add(selectResolutionLabel);
        selectResolutionPanel.add(Box.createRigidArea(new Dimension(15,0)));
        selectResolutionPanel.add(lowRes);
        selectResolutionPanel.add(Box.createRigidArea(new Dimension(5,0)));
        selectResolutionPanel.add(mediumRes);
        selectResolutionPanel.add(Box.createRigidArea(new Dimension(5,0)));
        selectResolutionPanel.add(highRes);

        exportFrame.add(buttonPanel, BorderLayout.SOUTH);
        exportFrame.add(selectMazesPanel, BorderLayout.CENTER);
        exportFrame.add(selectResolutionPanel, BorderLayout.NORTH);
        GridBagConstraints constraints = setupGridBag(selectResolutionPanel);
        constraints.anchor = GridBagConstraints.LINE_START;

        String[] columnNames = {"Title", "Username", "Creation_date", "Creation_time", "Last_edit_date", "Last_edit_time"};

        ResultSet rs = DatabaseHelper.db.getMazes();
        int rows = DatabaseHelper.db.countResultSet();
        String[][] data = DatabaseHelper.db.readResultSet(rs, rows);
        DefaultTableModel tableModel = new DefaultTableModel(data, columnNames);
        mazeTable = new JTable(tableModel);
        mazeTable.setAutoCreateRowSorter(true);
        mazeTable.setShowHorizontalLines(false);
        mazeTable.setRowSelectionAllowed(true);
        mazeTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent event) {
                event.getValueIsAdjusting();
            }
        });

        mazeTable.setSelectionForeground(Color.white);
        mazeTable.setSelectionBackground(Color.green);

        JScrollPane pane = new JScrollPane(mazeTable);
        pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        exportFrame.add(pane, BorderLayout.CENTER);
        exportFrame.setLocationRelativeTo(null);
        exportFrame.setVisible(true);
    }

    /**
     * Creates a popup window for errors
     * @param message the error message to display
     */
    private void createErrorDialog(String message){
        JPanel errorPanel = createPanel();
        JOptionPane.showMessageDialog(errorPanel, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    /**
     * Creates a popup window for information/acknowledgement of a successful action
     */
    private void createSuccessDialog(){
        JPanel successPanel = createPanel();
        JOptionPane.showMessageDialog(successPanel, "Your account has been successfully created. \nYou may now login with your username and password.", "Success", JOptionPane.PLAIN_MESSAGE);
    }

    /**
     * Creates the window for editing a maze by choosing a maze from a table
     * @throws SQLException
     */
    private void createEditWindow() throws SQLException {
        JFrame editFrame = createFrame(500,620,"Maze Creator - Edit");

        // Create a panel to hold all the other components
        JPanel topPanel = createPanel();
        topPanel.setBounds(0,0,500,600);
        JPanel buttonPanel = createPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.TRAILING));
        editFrame.add(buttonPanel, "South");

        JButton editButton = createButton("Edit");
        JButton cancelButton = createButton("Back");

        buttonPanel.add(editButton);
        editButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
        buttonPanel.add(cancelButton);
        cancelButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10,250,20,20));

        String[] columnNames = {"Title", "Username", "Creation_date", "Creation_time", "Last_edit_date", "Last_edit_time"};

        ResultSet rs = DatabaseHelper.db.getMazes();
        int rows = DatabaseHelper.db.countResultSet();
        String[][] data = DatabaseHelper.db.readResultSet(rs, rows);

        DefaultTableModel tableModel = new DefaultTableModel(data, columnNames);
        mazeTable = new JTable(tableModel);
        mazeTable.setAutoCreateRowSorter(true);
        mazeTable.setShowHorizontalLines(false);
        mazeTable.setRowSelectionAllowed(true);

        mazeTable.setSelectionForeground(Color.white);
        mazeTable.setSelectionBackground(Color.green);

        JScrollPane pane = new JScrollPane(mazeTable);
        pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        editFrame.add(pane, BorderLayout.CENTER);
        editFrame.setLocationRelativeTo(null);
        editFrame.setVisible(true);

    }
}