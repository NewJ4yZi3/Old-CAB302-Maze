package Program;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.*;
import java.io.Serial;
import java.io.Serializable;

/**
 * A custom Listener class required for the glass pane to interpret mouse events.
 */
class GlassListener implements MouseListener, MouseMotionListener, Serializable {
    @Serial
    private static final long serialVersionUID = -2954776321617980156L;
    JPanel gridPanel;
    Boolean coloring;
    private Point currentPoint;
    private int oldX;
    private int oldY;
    private final Border panelHighlighter = BorderFactory.createLineBorder(Color.GRAY);

    public GlassListener(JPanel underPane) {
        gridPanel = underPane;
        oldX = 0;
        oldY = 0;

    }
    public void mouseDragged(MouseEvent e) {
        Container panel = (JPanel) e.getSource();
        currentPoint = e.getPoint();
        Component comp = gridPanel.findComponentAt(currentPoint);
        if (coloring) comp.setBackground(Color.BLACK);
        else comp.setBackground(Color.WHITE);
        panel.revalidate();
    }
    @Override
    public void mouseClicked(MouseEvent e) {
        Container panel = (JPanel) e.getSource();
        currentPoint = e.getPoint();
        Component comp = gridPanel.findComponentAt(currentPoint);
        if (comp.getBackground().equals(Color.BLACK))comp.setBackground(Color.WHITE);
        else comp.setBackground(Color.BLACK);
        panel.revalidate();
    }
    public void mousePressed(MouseEvent e) {
        Container panel = (JPanel) e.getSource();
        currentPoint = e.getPoint();
        Component comp = gridPanel.findComponentAt(currentPoint);
        coloring = !comp.getBackground().equals(Color.BLACK);
        panel.revalidate();
    }
    public void mouseReleased(MouseEvent e) {
    }
    public void mouseMoved(MouseEvent e) {

        Container panel = (JPanel) e.getSource();
        currentPoint = e.getPoint();
        Component comp = gridPanel.findComponentAt(currentPoint);
        JPanel currentCell = (JPanel) comp;
        Component oldComp = gridPanel.findComponentAt(oldX,oldY);
        JPanel oldCell = (JPanel) oldComp;
        if (currentCell.equals(oldCell)){
            currentCell.setBorder(panelHighlighter);
            oldX = currentPoint.x;
            oldY = currentPoint.y;
        }
        else if (!currentCell.equals(oldCell)){
            oldCell.setBorder(null);
            oldX = currentPoint.x;
            oldY = currentPoint.y;
        }
        panel.revalidate();
    }
    public void mouseEntered(MouseEvent e) {
    }
    public void mouseExited(MouseEvent e) {

    }


}


