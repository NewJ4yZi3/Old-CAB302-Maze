package Program;

import java.io.IOException;
import java.io.Serial;
import java.io.Serializable;
import java.sql.SQLException;

/**
 * Represents a Maze with a title, author and unique mazeID (plus metadata)
 */
public class Maze implements Serializable {
    @Serial
    private static final long serialVersionUID = 7067248354814402042L;
    private String title;
    private final int authorId;
    private MazeObject maze;

    /**
     * Constructs a Maze instance and adds it to the database4
     * @param title the title of the maze
     * @param authorId the unique id of the author of the maze
     * @param maze the MazeObject instance connected to the maze file
     */
    public Maze(String title, int authorId, MazeObject maze) throws SQLException, IOException, ClassNotFoundException {
        this.title = title;
        this.authorId = authorId; //unique id of the author
        this.maze = maze;
    }

    /**
     * Gets the title of the maze
     * @return the title
     */
    public String getTitle() {
        return this.title;
    }

    /**
     * Sets the title of the maze
     * @param newTitle the maze's new title
     */
    public void setTitle(String newTitle) {
        this.title = newTitle;
    }

    /**
     * Gets the id of the author of the maze
     * @return the author
     */
    public int getAuthor() {
        return this.authorId;
    }

    /**
     * Gets the MazeObject instance of the maze
     * @return the MazeObject instance
     */
    public MazeObject getMaze(){
        return this.maze;
    }

    /**
     * Sets the MazeObject instance of the maze (for the purposes of saving to the database)
     * @param maze the new/edited version of the MazeObject instance
     */
    public void setMaze(MazeObject maze){
        this.maze = maze;
    }
}
