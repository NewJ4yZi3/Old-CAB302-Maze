package Program;

import java.io.IOException;
import java.io.Serial;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.HashMap;

/**
 * Represents a MazeDesigner type of Account
 */
public class MazeDesigner extends Account implements Serializable {

    @Serial
    private static final long serialVersionUID = 5023648998768100371L;

    /**
     * Constructs a MazeDesigner type of Account
     * @param username The name of the MazeDesigner Account
     * @param password The password of MazeDesigner Account
     */
    public MazeDesigner(String username, String password) throws SQLException {
        super(username, password, "MazeDesigner");
    }

    /**
     * Edits an existing Maze in the database
     * @param title the title of the Maze that a Maze Designer wants to edit
     */
    MazeObject editMaze(String title) throws SQLException, IOException, ClassNotFoundException {
        return DatabaseHelper.db.getMazeObj(DatabaseHelper.db.getMazeFileId(title, this.getAccountId()));
    }

    /**
     * Creates a new MazeObject instance
     * @param MazeTitle the title of the new Maze
     * @param size the Size of the mazeObject
     * @param imagePaths the file path of the image (starting image, ending image or logo) chosen for the maze
     * @param isGenerated true if the MazeObject to be created is a manual maze, false if the MazeObject to be created is an automatic maze
     * @return the new MazeObject that is created
     */
    private MazeObject createMazeObject(Size size, String MazeTitle, HashMap<String,String> imagePaths, boolean isGenerated) {
        return new MazeObject(size, MazeTitle, imagePaths, isGenerated, this.getAccountId());
    }

    /**
     * Register a new Maze to the database
     * @param size the size of the maze
     * @param title the title of the maze
     * @param imagePaths the file path of the image (starting image, ending image or logo) chosen for the maze
     * @param isGenerated true if the MazeObject to be created is a manual maze
     * @return the new Maze instance created
     * @throws SQLException
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public Maze createMazeFile(Size size, String title, HashMap<String,String> imagePaths, boolean isGenerated) throws SQLException, IOException, ClassNotFoundException {
        return new Maze(title, this.getAccountId(), createMazeObject(size, title, imagePaths, isGenerated));
    }

    /**
     * Adds listeners to the mazeObject
     * @param mazeObject the MazeObject of the Maze instance
     * @throws SQLException
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public void addListeners(MazeObject mazeObject) throws SQLException, IOException, ClassNotFoundException {
        MazeFrameListener listener = new MazeFrameListener(mazeObject);
        mazeObject.moveImages.addActionListener(listener);
        mazeObject.solveButton.addActionListener(listener);
        mazeObject.showDeadEnds.addActionListener(listener);
        mazeObject.exitButton.addActionListener(listener);
        mazeObject.saveButton.addActionListener(listener);
        mazeObject.save.addActionListener(listener);
        mazeObject.exitItem.addActionListener(listener);
        mazeObject.addWindowListener(listener);
    }

    /**
     * Saves a Maze to the database
     * @param maze the maze object that is to be saved into the database
     */
    public void saveMaze(String title, MazeObject maze) throws SQLException, IOException {
        DatabaseHelper.db.saveMazeFile(title, this.getAccountId(), maze);
    }
}
