package Program;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.Serial;
import java.io.Serializable;
import java.sql.SQLException;

/**
 * A custom Listener class for the MazeObject class
 */
public class MazeFrameListener extends WindowAdapter implements ActionListener, Serializable {
    @Serial
    private static final long serialVersionUID = -4729333416764369371L;
    private final MazeObject mazeObject;
    private final MazeDesigner currentMazeDesigner;

    public MazeFrameListener(MazeObject maze) throws SQLException, IOException, ClassNotFoundException {
        this.mazeObject = maze;
        currentMazeDesigner = (MazeDesigner) DatabaseHelper.db.getAccountObj(mazeObject.getAuthId());
    }

    public void windowClosing(WindowEvent e) {
        super.windowClosing(e);
        int choices = createSaveDialog(null, createSaveOptions());
        if(choices == 0)
        {
            trySave();
            System.exit(0);
        }
        if (choices == 1)
        {
            System.exit(0);
        }
    }
    public void windowOpened(WindowEvent e) {
        super.windowOpened(e);
        mazeObject.clearSolution();
    }

    public void actionPerformed(ActionEvent e) {
        String btnString = e.getActionCommand();
        Component comp = (Component) e.getSource();
        JFrame window = (JFrame) SwingUtilities.windowForComponent(comp);
        Object[] options = createSaveOptions();

        if (btnString.equals("Save to Database") || btnString.equals("Save")) {
            trySave();
        }
        if (btnString.equals("solve")) {
            if (mazeObject.solveButton.isSelected()) {
                mazeObject.drawSolution();
                if (mazeObject.isSolvable()){
                    mazeIsSolvableConfirm(window);
                }
                if (!mazeObject.isSolvable()){
                    mazeIsSolvableConfirm(window);
                }
            } else {
                mazeObject.clearSolution();
            }
            mazeObject.showPercentageUnused.setText("Space used by solution: " +
                    mazeObject.getSolutionExplorableSpace() + "%");
        }
        if (btnString.equals("Dead ends")) {
            if (mazeObject.showDeadEnds.isSelected()) {

                mazeObject.showDeadEnds.setText("Dead ends: " +
                        mazeObject.getDeadEnds() + " " + "(" +
                        mazeObject.getPercentageDeadEnds() + "%)");
            }
            if (!mazeObject.showDeadEnds.isSelected()) {
                mazeObject.showDeadEnds.setText("Show dead ends");
            }
        }
        if (btnString.equals("Exit Program")) {
            System.exit(0);
        }
        if (btnString.equals("Exit Design")) {
            int choices = createSaveDialog(window, options);
            if(choices == 0)
            {
                trySave();
                window.dispose();
            }
            if (choices == 1)
            {
                window.dispose();
            }
        }
        if (btnString.equals("New")) {
            int choices = createSaveDialog(window, options);
            if(choices == 0)
            {
                trySave();
                window.dispose();
            }
            if (choices == 1)
            {
                window.dispose();
            }
        }
        if (btnString.equals("Disable glass")) {
            if (mazeObject.moveImages.isSelected()) {
                mazeObject.glass.setVisible(false);
            }
            if (!mazeObject.moveImages.isSelected()) {
                mazeObject.glass.setVisible(true);
            }
        }
    }

    private int createSaveDialog(JFrame frame, Object[] options) {
        return JOptionPane.showOptionDialog(frame, "Would you like to save your design?", "Save?", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[2]);
    }

    private void mazeIsSolvableConfirm(JFrame frame)
    {
        if (mazeObject.isSolvable()){
            JOptionPane.showMessageDialog(frame, "Maze is Solvable!",
                    "Solvable Check", JOptionPane.PLAIN_MESSAGE);
        }
        else if (!mazeObject.isSolvable()){
            JOptionPane.showMessageDialog(frame, "Maze is not Solvable!",
                    "Solvable Check", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Object[] createSaveOptions() {
        return new Object[]{"Save", "Don't save", "Cancel"};
    }

    private void trySave() {
        try {
            mazeObject.clearSolution();
            currentMazeDesigner.saveMaze(this.mazeObject.getTitle(), this.mazeObject);
        } catch (SQLException | IOException ex) {
            ex.printStackTrace();
        }
        mazeObject.clearSolution();
    }
}
