package Program;

import javax.swing.*;
import java.awt.*;
import java.io.Serial;
import java.io.Serializable;

public class MazeGUI extends JFrame implements Serializable {
    private static final Dimension frameSize = new Dimension(910, 1025);
    @Serial
    private static final long serialVersionUID = -309731644033400708L;
    protected JCheckBox moveImages;
    protected JButton saveButton;
    protected JButton exitButton;
    protected JCheckBox solveButton;
    protected JMenuItem save;
    protected JCheckBox showDeadEnds;
    protected JLabel showPercentageUnused;
    protected JMenuItem exitItem;

    /**
     * Construct  the JFrame for the MazeObject
     * @param title The title the maze was given by the user
     */
    public MazeGUI(String title) {
        setTitle(title);
        setSize(frameSize.width, frameSize.height);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLocationRelativeTo(null);

        JMenuBar menuBar = new JMenuBar();
        JMenu file = new JMenu("File");

        save = new JMenuItem("Save");
        exitItem = new JMenuItem("Exit Program");
        file.add(save);
        file.add(exitItem);

        menuBar.add(file);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setLayout(new FlowLayout(FlowLayout.TRAILING, 20, 10));

        showDeadEnds = new JCheckBox("Show dead ends");
        showDeadEnds.setSelected(false);
        showDeadEnds.setActionCommand("Dead ends");

        showPercentageUnused = new JLabel("Space used by solution: ");

        solveButton = new JCheckBox("Show Solution");
        solveButton.setSelected(false);
        solveButton.setActionCommand("solve");

        moveImages = new JCheckBox("Move Images");
        moveImages.setSelected(false);
        moveImages.setActionCommand("Disable glass");

        saveButton = new JButton("Save to Database");

        exitButton = new JButton("Exit Design");

        buttonPanel.add(showDeadEnds);
        showDeadEnds.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonPanel.add(showPercentageUnused);
        showPercentageUnused.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonPanel.add(solveButton);
        solveButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonPanel.add(moveImages);
        moveImages.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonPanel.add(saveButton);
        saveButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonPanel.add(exitButton);
        exitButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));

        add(menuBar, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);
    }
}

