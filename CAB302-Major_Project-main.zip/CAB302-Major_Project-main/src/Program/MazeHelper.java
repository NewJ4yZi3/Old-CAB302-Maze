package Program;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * Represents a list of methods that helps the MazeDesigner methods
 */

public class MazeHelper implements Serializable {
    @Serial
    private static final long serialVersionUID = 1844132207419530417L;
    private static final int[][] DIRECTIONS = { { 0, 1 }, { 1, 0 }, { 0, -1 }, { -1, 0 } };

    /**
     * Calculates the optimal solution for a maze
     * @param mazeObject the MazeObject instance to calculate the optimal solution for
     * @return the list of nodes that make up the optimal solution
     */
    public List<Node> calculateOptimalSolution(MazeObject mazeObject) {
        LinkedList<Node> nextToVisit = new LinkedList<>();
        Node start = mazeObject.getEntry();
        nextToVisit.add(start);

        while (!nextToVisit.isEmpty()) {
            Node current = nextToVisit.remove();

            if (!mazeObject.isValidLocation(current.getCellRow(), current.getCellColumn()) || mazeObject.isExplored(current.getCellRow(), current.getCellColumn())) {
                continue;
            }

            if (mazeObject.isWall(current.getCellRow(), current.getCellColumn())) {
                mazeObject.setVisited(current.getCellRow(), current.getCellColumn());
                continue;
            }

            if (mazeObject.isExit(current.getCellRow(), current.getCellColumn())) {
                return backtrackPath(current);
            }

            for (int[] direction : DIRECTIONS) {
                Node node = new Node(current.getCellRow() + direction[0], current.getCellColumn() + direction[1], current);
                nextToVisit.add(node);
                mazeObject.setVisited(current.getCellRow(), current.getCellColumn());
            }
        }
        return Collections.emptyList();
    }

    /**
     * Backtracks the current node if it is not a valid node for the optimal solution
     * @param cur the current node
     * @return the path without the current node
     */
    private List<Node> backtrackPath(Node cur) {
        List<Node> path = new ArrayList<>();
        Node iteration = cur;

        while (iteration != null) {
            path.add(iteration);
            iteration = iteration.parentNode;
        }

        return path;
    }
}
