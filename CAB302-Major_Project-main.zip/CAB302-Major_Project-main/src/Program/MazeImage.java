package Program;

import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.nio.file.Path;
import javax.imageio.*;
import javax.swing.*;

public class MazeImage implements Serializable {

    @Serial
    private static final long serialVersionUID = 1388030036582289737L;

    /**
     * Creates a buffered image of the pane the maze is held in.
     * @param maze The layered pane the maze is held in.
     * @return Buffered image of the maze.
     */
    public static BufferedImage createMazeImage(JLayeredPane maze) {

        Dimension d = maze.getSize();
        BufferedImage bufferedImage = new BufferedImage(d.width, d.height, BufferedImage.SCALE_SMOOTH);
        Graphics2D g = bufferedImage.createGraphics();
        maze.print(g);
        g.dispose();
        return bufferedImage;
    }

    /**
     * Creates a buffered image of the maze with the optimal solution highlighted
     * @param mazeObject the mazeObject
     * @param maze the layered pane the maze is held in
     * @return Buffered image of the maze with the optimal solution
     */
    public static BufferedImage createSolutionImage( MazeObject mazeObject, JLayeredPane maze) {
        mazeObject.drawSolution();
        Dimension d = maze.getSize();
        BufferedImage bufferedImage = new BufferedImage(d.width, d.height, BufferedImage.SCALE_SMOOTH);
        Graphics2D g = bufferedImage.createGraphics();
        maze.print(g);
        g.dispose();
        return bufferedImage;
    }

    /**
     *  Write the maze image to a File.
     *  @param	 mazeImage mazeImage to be written
     *  @param	 fileName name of file to be created
     *  @exception IOException if an error occurs during writing
     */
    public static void writeImage(BufferedImage mazeImage, FileType fileType, Path fileName) throws IOException {
        if (fileName == null) return;

        String type = fileType.getFileType();

        File filePath = new File(String.valueOf(fileName));

        ImageIO.write(mazeImage, type, filePath);


    }

    /**
     * Converts a buffered image to a byte array to save into the database
     * @param mazeImage the buffered image
     * @param fileType the file type of the buffered image
     * @return the buffered image as a byte array
     * @throws IOException
     */
    public static byte[] convertMazeImage(BufferedImage mazeImage, FileType fileType) throws IOException {
        String type = fileType.getFileType();
        ByteArrayOutputStream baos = null;
        try {
            baos = new ByteArrayOutputStream();
            ImageIO.write(mazeImage, type, baos);
            return baos.toByteArray();
        } finally {
            try {
                assert baos != null;
                baos.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}