package Program;

import javax.swing.*;
import java.awt.*;
import java.io.Serial;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

/**
 * Represents the Maze object
 */
public class MazeObject extends MazeGUI implements  Serializable {

    @Serial
    private static final long serialVersionUID = 8545713822210407557L;
    private static Dimension containerSize;
    final int rows;
    final int columns;
    final JPanel[][] cellPanels;
    private final Random randomGenerator = new Random();
    Dimension cellDimension;
    final JPanel glass;
    private final JLayeredPane layeredPane;
    private final Node startingPoint;
    private final Node endPoint;
    private boolean[][] visited;
    private List<Node> path;
    private final int authId;
    /**
     * Constructs a maze or blank canvas for the user
     * @param size the size of the maze as an int equal for both columns and rows
     * @param title The title of the maze the user has given
     * @param imagePaths A hashMap containing the string path of the images to be used
     * @param isGenerated Boolean value for whether to automatically generate a maze or not
     */
    public MazeObject(Size size, String title, HashMap<String,String> imagePaths, boolean isGenerated, int id){
        super(title);
        authId = id;
        int dimensions = size.getSize();
        rows = dimensions;
        columns = dimensions;
        visited = new boolean[rows][columns];
        int cellSize = size.getCellSize();
        cellDimension = new Dimension(cellSize, cellSize);
        int measurement = dimensions * cellSize;
        containerSize = new Dimension(measurement, measurement);
        // Set the start and end point of maze
        startingPoint = new Node(0, 1);
        endPoint = new Node(rows - 1, columns - 2);

        // Layered pane to hold image over maze
        layeredPane = new JLayeredPane();
        // Functionality to change the location of image over maze
        MoveImageListener moveImageListener = new MoveImageListener(layeredPane);
        layeredPane.addMouseListener(moveImageListener);
        layeredPane.addMouseMotionListener(moveImageListener);

        // Resize and place image if not null
        int scaleFactor = size.getScaleFactor();
        int imageSize = cellSize * scaleFactor;
        int xPosition = getRandomNumber(cellSize, ((containerSize.width - 1) - imageSize));
        int yPosition = getRandomNumber(cellSize, ((containerSize.height - 1) - imageSize));
        // If there is an image create a JLabel for it and place on layered pane
        if (!imagePaths.isEmpty()) {
            if (imagePaths.containsKey("Logo")) {
                String logoPath = imagePaths.get("Logo");
                ImageIcon logoIcon = new ImageIcon(new ImageIcon(logoPath).getImage().getScaledInstance(imageSize, imageSize, Image.SCALE_DEFAULT));
                JLabel logoLabel = new JLabel(logoIcon);
                logoLabel.setBounds(xPosition, yPosition, imageSize, imageSize);
                layeredPane.add(logoLabel, JLayeredPane.PALETTE_LAYER);
            }
            if (imagePaths.containsKey("Start")) {
                String startPath = imagePaths.get("Start");
                ImageIcon startIcon = new ImageIcon(new ImageIcon(startPath).getImage().getScaledInstance(imageSize, imageSize, Image.SCALE_DEFAULT));
                JLabel startLabel = new JLabel(startIcon);
                int x = (startingPoint.getCellRow() + 1) * cellSize;
                int y = startingPoint.getCellColumn() * cellSize;
                startLabel.setBounds(x, y, imageSize, imageSize);
                layeredPane.add(startLabel, JLayeredPane.PALETTE_LAYER);
            }
            if (imagePaths.containsKey("Finish")) {
                String finishPath = imagePaths.get("Finish");
                ImageIcon finishIcon = new ImageIcon(new ImageIcon(finishPath).getImage().getScaledInstance(imageSize, imageSize, Image.SCALE_DEFAULT));
                JLabel finishLabel = new JLabel(finishIcon);
                int x = (endPoint.getCellRow() * cellSize) - imageSize;
                int y = ((endPoint.getCellColumn() + 1) * cellSize) - imageSize;
                finishLabel.setBounds(x,y, imageSize, imageSize);
                layeredPane.add(finishLabel, JLayeredPane.PALETTE_LAYER);
            }

            // Disable button if no logo
        } else {
            moveImages.setEnabled(false);
        }

        JPanel gridPanel;
        // If automatic generation of maze was selected
        if (isGenerated) {
            gridPanel = createPanel();
            cellPanels = new JPanel[rows][columns];
            //Set the entire grid to black and initialize
            for (int i = 0; i < columns; i++) {
                for (int j = 0; j < rows; j++) {
                    cellPanels[i][j] = new JPanel();
                    cellPanels[i][j].setOpaque(true);
                    cellPanels[i][j].setPreferredSize(cellDimension);
                    cellPanels[i][j].setBackground(Color.BLACK);
                    gridPanel.add(cellPanels[i][j]);
                }
            }
            // Set the cells behind the logo to blue to avoid path being cut behind it
            if (imagePaths.containsKey("Logo")) {
                for (int i = (yPosition / cellSize) + 1; i <= (yPosition / cellSize) + scaleFactor - 1; i++) {
                    for (int j = (xPosition / cellSize) + 1; j <= (xPosition / cellSize) + scaleFactor - 1; j++) {
                        cellPanels[i][j].setBackground(Color.BLUE);
                    }
                }
            }
            //Starting from row and column 1 and 1
            cellPanels[endPoint.getCellRow()][endPoint.getCellColumn()].setBackground(Color.RED);
            cellPanels[startingPoint.getCellRow()][startingPoint.getCellColumn()].setBackground(Color.GREEN);
            pathGenerator(cellPanels, startingPoint.getCellRow() + 1, startingPoint.getCellColumn());
            layeredPane.revalidate();
            // Set cells behind logo back to black after path generated
            if (imagePaths.containsKey("Logo")) {
                for (int i = (yPosition / cellSize) - 1; i <= (yPosition / cellSize) + scaleFactor; i++) {
                    for (int j = (xPosition / cellSize) - 1; j <= (xPosition / cellSize) + scaleFactor; j++) {
                        cellPanels[i][j].setBackground(Color.BLACK);
                    }
                }
            }
            if (imagePaths.containsKey("Start")) {
                for (int i = startingPoint.getCellRow() + 1 ; i < (startingPoint.getCellRow() + 1) + scaleFactor; i++) {
                    for (int j = startingPoint.getCellColumn(); j < startingPoint.getCellColumn() + scaleFactor; j++) {
                        cellPanels[i][j].setBackground(Color.WHITE);
                    }
                }
            }
            if (imagePaths.containsKey("Finish")) {
                for (int i = endPoint.getCellRow() - scaleFactor ; i < (endPoint.getCellRow()); i++) {
                    for (int j = (endPoint.getCellColumn() + 1) - scaleFactor; j < endPoint.getCellColumn() + 1; j++) {
                        cellPanels[i][j].setBackground(Color.WHITE);
                    }
                }
            }
            // If manual maze was selected, create blank grid
        } else {
            gridPanel = createPanel();
            cellPanels = new JPanel[rows][columns];
            createCellPanels(columns, rows);
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < columns; j++) {
                    cellPanels[i][j].setPreferredSize(cellDimension);
                    gridPanel.add(cellPanels[i][j]);
                    if(i == 0 || j == 0 || i == rows - 1 || j == columns - 1){
                        cellPanels[i][j].setBackground(Color.BLACK);
                    }
                }
            }
            cellPanels[endPoint.getCellRow()][endPoint.getCellColumn()].setBackground(Color.RED);
            cellPanels[startingPoint.getCellRow()][startingPoint.getCellColumn()].setBackground(Color.GREEN);
        }

        // Our main panel that holds the gridPanel and has a glassPane for event handling
        JRootPane mainPanel = new JRootPane();
        mainPanel.setContentPane(gridPanel);
        mainPanel.setSize(layeredPane.getWidth(), layeredPane.getHeight());
        glass = new JPanel();
        GlassListener glassListener = new GlassListener(gridPanel);
        glass.addMouseListener(glassListener);
        glass.addMouseMotionListener(glassListener);
        glass.setOpaque(false);

        mainPanel.setBounds(0, 0, containerSize.width, containerSize.height);
        layeredPane.add(mainPanel, JLayeredPane.DEFAULT_LAYER);
        JPanel holderPanel = new JPanel();
        holderPanel.setPreferredSize(new Dimension(containerSize.width, containerSize.height));
        holderPanel.setLayout(new BorderLayout());
        holderPanel.add(layeredPane, BorderLayout.CENTER);


        mainPanel.setGlassPane(glass);
        JScrollPane directoryPane = new JScrollPane(holderPanel);
        super.add(directoryPane, BorderLayout.CENTER);
        glass.setVisible(true);
        super.setVisible(true);

    }

    /**
     * Gets the unique Account Id of the author of the maze
     * @return the unique Account Id
     */
    public int getAuthId(){return authId;}

    /**
     * Gets the starting node of the solution for the maze
     * @return the Node
     */
    public Node getEntry() {
        int row = startingPoint.getCellRow() + 1;
        int column = startingPoint.getCellColumn();
        return new Node(row, column);
    }

    /**
     * Checks if the cell is the exit cell
     * @param x cell row
     * @param y cell column
     * @return true if the cell is the exit cell
     */
    public boolean isExit(int x, int y) {
        int row = endPoint.getCellRow() - 1;
        int column = endPoint.getCellColumn();
        Node end = new Node(row, column);
        return x == end.getCellRow() && y == end.getCellColumn();
    }

    /**
     * Checks if the cell has already been explored or not
     * @param row the cell row
     * @param col the cell column
     * @return true if the cell has already been explored
     */
    public boolean isExplored(int row, int col) {
        return visited[row][col];
    }

    /**
     * Checks if a cell is a wall
     * @param row the cell row
     * @param col the cell column
     * @return true if the cell is a wall
     */
    public boolean isWall(int row, int col) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (cellPanels[row][col].getBackground().equals(Color.BLACK)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Sets the cell as already visited
     * @param row the cell row
     * @param col the cell column
     */
    public void setVisited(int row, int col) {
        visited[row][col] = true;
    }

    /**
     * Checks if a cell is a valid location and not a border cell
     * @param row the cell row
     * @param col the cell column
     * @return true if the cell is not a border cell
     */
    public boolean isValidLocation(int row, int col) {
        return row >= 1 && row < rows - 1 && col >= 1 && col < columns - 1;
    }

    /**
     * Draws the solution path through the maze red
     */
    public void drawSolution() {
        MazeHelper mazeHelper = new MazeHelper();
        if (path != null) {
            for (boolean[] booleans : visited) {
                for (int j = 0; j < visited.length; j++) {
                    Arrays.fill(booleans, false);
                }
            }
            path.clear();
        }
        path = mazeHelper.calculateOptimalSolution(this);
        for (Node node : path) {
            cellPanels[node.getCellRow()][node.getCellColumn()].setBackground(Color.RED);
        }
    }

    /**
     * Clears the solution path
     */
    public void clearSolution(){
        if (!(path == null)) {
            for (Node node : path) {
                if (!(cellPanels[node.getCellRow()][node.getCellColumn()].getBackground().equals(Color.BLACK))) {
                    cellPanels[node.getCellRow()][node.getCellColumn()].setBackground(Color.WHITE);
                }
            }
        }

    }

    /**
     * Generates a random number
     * @param origin the minimum value allowed
     * @param bound the maximum value allowed
     * @return a random number
     */
    private static int getRandomNumber(int origin, int bound) {
        Random r = new Random();
        int random = r.nextInt(origin, bound);
        return (random % origin == 0) ? random : getRandomNumber(origin, bound);
    }

    /**
     * Creates a JPanel for use
     * @return the JPanel
     */
    private JPanel createPanel() {
        JPanel container = new JPanel();
        container.setLayout(createLayout(rows, columns));
        container.setPreferredSize(containerSize);
        container.setBounds(0, 0, containerSize.width, containerSize.height);
        return container;
    }

    /**
     * Creates a grid of cells
     * @param rows the number of rows
     * @param columns the number of columns
     */
    private void createCellPanels(int rows, int columns) {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                cellPanels[i][j] = new JPanel();
                cellPanels[i][j].setOpaque(true);
                cellPanels[i][j].setBackground(Color.white);
            }
        }
    }

    /**
     * Gets the layeredPane of the MazeObject
     * @return the layeredPane
     */
    public JLayeredPane getLayeredPane() {
        return layeredPane;
    }

    /**
     * Creates a GridLayout for use
     * @param rows The value of the rows required
     * @param columns The value of the columns required
     * @return The GridLayout with the required rows and columns
     */
    private GridLayout createLayout(int rows, int columns) {
        return new GridLayout(rows, columns);
    }

    /**
     * Checks if a cell has been visited or not
     * @param cellPanels The grid of cells
     * @param cellRow the current cell row
     * @param cellColumn the current cell column
     * @return true if the cell has been visited
     */
    private boolean notBeenVisited(JPanel[][] cellPanels, int cellRow, int cellColumn) {
        if (!(cellColumn + 2 > rows - 2) && (cellPanels[cellRow][cellColumn + 2].getBackground() == Color.BLACK)) {
            return true;
        }
        if (!(cellColumn - 2 < 0) && (cellPanels[cellRow][cellColumn - 2].getBackground() == Color.BLACK)) {
            return true;
        }
        if (!(cellRow + 2 > columns - 2) && (cellPanels[cellRow + 2][cellColumn].getBackground() == Color.BLACK)) {
            return true;
        }
        return !(cellRow - 2 < 0) && (cellPanels[cellRow - 2][cellColumn].getBackground() == Color.BLACK);
    }

    /**
     * Creates a path by visiting cells and turning it to white
     * @param cellPanels The grid of cells
     * @param cellRow The starting point cell row
     * @param cellColumn The starting point cell column
     */
    private void pathGenerator(JPanel[][] cellPanels, int cellRow, int cellColumn) {
        //Sets current cell to white to mark as visited
        cellPanels[cellRow][cellColumn].setBackground(Color.WHITE);
        //Stop from cutting into the border
        if (cellRow == columns - 1 || cellRow < 1) {
            return;
        } else if (cellColumn == rows - 1 || cellColumn < 1) {
            return;
        }
        //Gets a number between 0-3 and uses it to determine direction
        switch (randomGenerator.nextInt(4)) {
            case 0:
                if (notBeenVisited(cellPanels, cellRow, cellColumn)) {
                    if (!(cellColumn + 2 > rows - 2) && (cellPanels[cellRow][cellColumn + 2].getBackground() != Color.white)) {
                        if (!(cellColumn + 2 > rows - 2) && (cellPanels[cellRow][cellColumn + 2].getBackground() != Color.BLUE)) {
                            cellPanels[cellRow][cellColumn + 1].setBackground(Color.WHITE);
                            pathGenerator(cellPanels, cellRow, cellColumn + 2);
                        }
                    }
                    pathGenerator(cellPanels, cellRow, cellColumn);
                }
                break;
            case 1:
                if (notBeenVisited(cellPanels, cellRow, cellColumn)) {
                    if (!(cellColumn - 2 < 0) && (cellPanels[cellRow][cellColumn - 2].getBackground() != Color.white)) {
                        if (cellPanels[cellRow][cellColumn - 2].getBackground() != Color.BLUE) {
                            cellPanels[cellRow][cellColumn - 1].setBackground(Color.WHITE);
                            pathGenerator(cellPanels, cellRow, cellColumn - 2);
                        }
                    }
                    pathGenerator(cellPanels, cellRow, cellColumn);
                }
                break;
            case 2:
                if (notBeenVisited(cellPanels, cellRow, cellColumn)) {
                    if (!(cellRow + 2 > columns - 2) && (cellPanels[cellRow + 2][cellColumn].getBackground() != Color.white)) {
                        if (!(cellRow + 2 > columns - 2) && (cellPanels[cellRow + 2][cellColumn].getBackground() != Color.BLUE)) {
                            cellPanels[cellRow + 1][cellColumn].setBackground(Color.WHITE);
                            pathGenerator(cellPanels, cellRow + 2, cellColumn);
                        }
                    }
                    pathGenerator(cellPanels, cellRow, cellColumn);
                }
                break;

            case 3:
                if (notBeenVisited(cellPanels, cellRow, cellColumn)) {
                    if (!(cellRow - 2 < 0) && (cellPanels[cellRow - 2][cellColumn].getBackground() != Color.white)) {
                        if (cellPanels[cellRow - 2][cellColumn].getBackground() != Color.BLUE) {
                            cellPanels[cellRow - 1][cellColumn].setBackground(Color.WHITE);
                            pathGenerator(cellPanels, cellRow - 2, cellColumn);
                        }
                    }
                    pathGenerator(cellPanels, cellRow, cellColumn);
                }
                break;
        }
    }

    /**
     * Determines if the cells in a direction a cell are black to identify dead ends
     * @param rows the current cell row
     * @param columns the current cell column
     * @return true if the cell has three cells in a direction that are black
     */
    private boolean endDirection(int rows, int columns){
        if (cellPanels[rows][columns-1].getBackground().equals(Color.BLACK) // LEFT
                && cellPanels[rows-1][columns].getBackground().equals(Color.BLACK) // UP
                && cellPanels[rows][columns+1].getBackground().equals(Color.BLACK)) // RIGHT
        {
            return true; //HEADING UP
        }
        if (cellPanels[rows][columns-1].getBackground().equals(Color.BLACK) // LEFT
                && cellPanels[rows-1][columns].getBackground().equals(Color.BLACK) // UP
                && cellPanels[rows+1][columns].getBackground().equals(Color.BLACK)) // DOWN
        {
            return true; //HEADING LEFT
        }
        if (cellPanels[rows][columns-1].getBackground().equals(Color.BLACK) // LEFT
                && cellPanels[rows][columns+1].getBackground().equals(Color.BLACK) // RIGHT
                && cellPanels[rows+1][columns].getBackground().equals(Color.BLACK)) // DOWN
        {
            return true; //HEADING DOWN
        }
        if (cellPanels[rows-1][columns].getBackground().equals(Color.BLACK) // LEFT
                && cellPanels[rows][columns+1].getBackground().equals(Color.BLACK) // RIGHT
                && cellPanels[rows+1][columns].getBackground().equals(Color.BLACK)) // DOWN
        {
            return true; //HEADING RIGHT
        }
        else{
            return false;
        }
    }

    /**
     * Finds the total amount of red in the maze
     * @param cellRow the current cell row
     * @param cellColumn the current cell column
     * @return total red frames
     */
    private int mazeRed (int cellRow, int cellColumn){
        //traverse the 2D array.
        int redCount = 0;
        for (int i = 0; i < cellRow; i++) {
            for (int j = 0; j < cellColumn; j++) {
                if (cellPanels[i][j].getBackground().equals(Color.RED)) {
                    redCount++;
                }
            }
        }
        return redCount;
    }

    /**
     * Finds the total amount of white in the maze
     * @param cellRow the current cell row
     * @param cellColumn the current cell column
     * @return total white frames
     */
    private int mazeWhite (int cellRow, int cellColumn){
        //traverse the 2D array.
        int whiteCount = 0;
        for (int i = 0; i < cellRow; i++) {
            for (int j = 0; j < cellColumn; j++) {
                if (cellPanels[i][j].getBackground().equals(Color.WHITE)) {
                    whiteCount++;
                }
            }
        }
        return whiteCount;
    }

    /**
     * Calculates the total dead ends in a maze
     * @param cellRow the current cell row
     * @param cellColumn the current cell column
     * @return total dead ends
     */
    private int calculateDeadEnds (int cellRow, int cellColumn){
        int deadEnds = 0;
        //traverse the 2D array.
        for (int i = 0; i < cellRow; i++) {
            for (int j = 0; j < cellColumn; j++) {
                if (cellPanels[i][j].getBackground().equals(Color.WHITE)) {
                    if (endDirection(i, j)){
                        deadEnds++;
                    }
                }
            }
        }
        return deadEnds;
    }

    /**
     * Gets the number of dead ends in the maze
     * @return the number of dead ends
     */
    public String getDeadEnds (){
        return (Integer.toString(calculateDeadEnds(rows, columns)));
    }

    /**
     * Calculates the total percentage of dead ends in the maze
     * @return percentage of dead ends
     */
    private int calculatePercentageDeadEnds (){
        int deadEnds = calculateDeadEnds(rows, columns);
        int redTotal = mazeRed(rows, columns);
        int whiteTotal = mazeWhite(rows, columns);
        int total = redTotal + whiteTotal - 1;
        return ((deadEnds * 100) / total);
    }

    /**
     * Gets the Percentage of the maze with dead ends
     * @return the percentage
     */
    public String getPercentageDeadEnds (){
        return (Integer.toString(calculatePercentageDeadEnds()));
    }

    /**
     * Calculates the total space that is occupied by the solution
     * @return total space occupied as a percentage
     */
    private int calculateSolutionExplorableSpace() {
        // code for calculating the amount explorable space of a maze
        int redTotal = mazeRed(rows, columns);
        int whiteTotal = mazeWhite(rows, columns);
        int total = redTotal + whiteTotal - 1;
        return ((redTotal * 100) / total);
    }

    /**
     * Gets the amount of Explorable space the solution is taking up
     * @return the amount of space
     */
    public String getSolutionExplorableSpace (){
        return (Integer.toString(calculateSolutionExplorableSpace()));
    }

    /**
     * Checks if the maze is solvable
     * @return true if the maze can be solved
     */
    public boolean isSolvable (){
        drawSolution();
        int rcount = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (cellPanels[i][j].getBackground().equals(Color.RED)) {
                    rcount++;
                }
            }
        }
        if (rcount > 1) {
            return true;
        }
        return false;
    }


}