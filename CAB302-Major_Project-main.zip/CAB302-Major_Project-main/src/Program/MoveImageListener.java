package Program;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.Serial;
import java.io.Serializable;

/**
 * A custom listener class for the moving images across the layered pane of the MazeObject class
 */
public class MoveImageListener implements MouseListener, MouseMotionListener, Serializable {
    @Serial
    private static final long serialVersionUID = 6876600758607484431L;
    private Boolean logoFound;
    private Component c;
    private final JLayeredPane thisFrame;

    public MoveImageListener(JLayeredPane layeredPane) {
        thisFrame = layeredPane;
    }
    @Override
    public void mouseDragged(MouseEvent e) {
        if (logoFound){
            c.setLocation(e.getX()-c.getWidth()/2,
                    e.getY()-c.getHeight()/2);
        }
    }
    @Override
    public void mouseMoved(MouseEvent e) {

    }
    @Override
    public void mouseClicked(MouseEvent e) {

    }
    @Override
    public void mousePressed(MouseEvent e) {
        c =  thisFrame.findComponentAt(e.getX(), e.getY());
        if (c instanceof JLabel){
            logoFound = true;
        }

    }
    @Override
    public void mouseReleased(MouseEvent e) {
        logoFound = false;
    }
    @Override
    public void mouseEntered(MouseEvent e) {

    }
    @Override
    public void mouseExited(MouseEvent e) {

    }
}

