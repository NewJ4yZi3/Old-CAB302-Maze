package Program;

import java.io.Serial;
import java.io.Serializable;

/**
 * Similar to a Point, a Node holds the cell row and column value and can hold the value of its parent node
 */
public class Node implements Serializable {

    @Serial
    private static final long serialVersionUID = -8674151859044940292L;
    int cellRow;
    int cellColumn;
    Node parentNode;

    /**
     * Constructs a Node (without a parent)
     * @param cellRow the row number of the node
     * @param cellColumn the column number of the node
     */
    public Node(int cellRow, int cellColumn) {
        this.cellRow = cellRow;
        this.cellColumn = cellColumn;
        this.parentNode = null;
    }

    /**
     * Constructs a Node (with a parent)
     * @param cellRow the row number of the node
     * @param cellColumn the column number of the node
     * @param parentNode the parent node of the current node
     */
    public Node(int cellRow, int cellColumn, Node parentNode) {
        this.cellRow = cellRow;
        this.cellColumn = cellColumn;
        this.parentNode = parentNode;
    }

    int getCellRow() {
        return cellRow;
    }

    int getCellColumn() {
        return cellColumn;
    }

    Node getParentNode() {
        return parentNode;
    }
}