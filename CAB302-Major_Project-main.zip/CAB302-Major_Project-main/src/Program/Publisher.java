package Program;

import java.io.Serial;
import java.sql.SQLException;

/**
 * Represents a Publisher type of Account
 */
public class Publisher extends Account{
    @Serial
    private static final long serialVersionUID = 8077601213582576410L;

    /**
     * Constructs an account
     * @param username The name of the account
     * @param password The password of the account
     */
    public Publisher(String username, String password) throws SQLException {
        super(username, password, "Publisher");
    }
}
