package Program;

/**
 * Represents an enumeration for Maze Resolution (useful for export)
 */
public enum Resolution {
    LOW(600, 600), MED(1000, 1000), HIGH(1600, 1600);

    private final int height;
    private final int width;

    Resolution(int height, int width) {
        this.height = height;
        this.width = width;
    }

    public int getHeight() {return height;}
    public int getWidth() {return width;}
}

