package Program;

/**
 * Represents an enumeration for Maze Size
 */
public enum Size {
    // these should have integer values that can be helpful for:
    //      making the canvas size
    //      setting the difficulty of the maze

    SMALL(25, 36,3), MEDIUM(37, 24, 5), LARGE(55, 16,  7), XLARGE(81, 11, 8);

    private final int dimension;
    private final int cellSize;
    private final int scaleFactor;

    Size(int dimension, int cellSize, int scaleFactor) {
        this.dimension = dimension;
        this.scaleFactor = scaleFactor;
        this.cellSize = cellSize;
    }

    public int getSize() {return dimension;}
    public int getCellSize() {return cellSize;}
    public int getScaleFactor() {return scaleFactor;}

}