package Program;

import java.io.Serial;
import java.sql.SQLException;

/**
 * Represents a SystemAdministrator type of Account
 */
public class SystemAdmin extends Account{

    @Serial
    private static final long serialVersionUID = 8145342746109513848L;

    /**
     * Constructs a System Administrator type of Account
     * @param username The name of the System Administrator account
     * @param password The password of the System Administrator account
     */
    public SystemAdmin(String username, String password) throws SQLException {
        super(username, password, "SystemAdmin");
        // default constructor because the system admin has only 1 username and password already supplied to them
    }
}
