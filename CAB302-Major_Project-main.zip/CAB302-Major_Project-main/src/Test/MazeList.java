
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.TreeSet;

public class MazeList {

    private HashMap<String, String> resolution = new HashMap<>();
    private TreeSet<String> mazes = new TreeSet<>();


    public void addMaze(String Maze_Name) throws MazeListException {
        if(!mazes.contains(Maze_Name)) {
            throw new MazeListException("Tried to add the same name to this maze as a pre-existing maze");
        }
        mazes.add(Maze_Name);
    }

    public String getResolution(String Maze_Name) throws MazeListException {

        if(!mazes.contains(Maze_Name)) {
            throw new MazeListException("This maze does not exist within the database");
        }
        String resRating = resolution.get(Maze_Name);
        if(resRating == null) {
            resRating = "Resolution = Low";
        }
        return resRating;
    }

    public void setResolution(String mazeName, int res) throws MazeListException {
        if (res < 600) {
            throw new MazeListException("The resolution is too low");
        }
        if (res > 1400) {
            throw new MazeListException("The resolution is too high");
        }
        if (!mazes.contains(mazeName)) {
            throw new MazeListException("The created maze does not have a name");
        }

        String resolutionRating = "Resolution = High".substring(1400, res);
        resolution.put(mazeName, resolutionRating);
    }

    public String getList(){
        StringBuilder sortedList = new StringBuilder();
        for (String maze : mazes) {
            sortedList.append(maze).append("\n");
        }
        return sortedList.toString();
    }




}
