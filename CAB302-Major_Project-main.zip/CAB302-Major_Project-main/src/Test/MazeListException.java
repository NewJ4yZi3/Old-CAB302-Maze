

    public class MazeListException extends Exception {

        public MazeListException(String message) {
            super(message);
        }
}