
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;


public class TestMain
{
    MazeList mazes;

    @BeforeEach
    @Test
    public void setUpMazeList()
    {
        mazes = new MazeList();
    }

    @Test
    public void addMaze() throws MazeListException
    {
        mazes.addMaze("Maze_Small");
        assertEquals("Resolution = Low", mazes.getResolution("Maze_Small"),
                "Adding a maze failed!");
    }

    @Test
    public void setResolution() throws MazeListException {
        mazes.addMaze("Maze_Medium");
        mazes.setResolution("Maze_Medium", 1000);
        assertEquals("****", mazes.getResolution("Maze_Medium"),
                "Could not set the correct resolution");
    }

    @Test
    public void exportSelectedMazes() throws MazeListException {
        String selectedMazeList =
                "Maze_Small\n" +
                        "Maze_Medium\n" +
                            "Maze_Large\n";
        mazes.addMaze("Maze_Small");
        mazes.addMaze("Maze_Medium");
        mazes.addMaze("Maze_Large");
        assertEquals(selectedMazeList, mazes.getList(), "Listing not complete");
    }

    @Test
    public void nonExistentDatabaseEntry() {
        assertThrows(MazeListException.class, () -> {
            mazes.getResolution("Maze_Extra_Large");
        });
    }

    @Test
    public void duplicateMaze() {
        assertThrows(MazeListException.class, () -> {
            mazes.addMaze("Maze 1");
            mazes.addMaze("Maze 2");
        });
    }

    @Test
    public void resolutionTooLow() {
        assertThrows(MazeListException.class, () -> {
            mazes.addMaze("Maze 3");
            mazes.setResolution("Maze 3", 0);
        });
    }

    @Test
    public void resolutionTooHigh() {
        assertThrows(MazeListException.class, () -> {
            mazes.addMaze("Maze 4");
            mazes.setResolution("Maze 4", 1801);
        });
    }
}